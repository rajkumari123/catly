export default Object.freeze({
  url: {
    baseServer: "/server/catly",
    getAllUrls: "/server/catly/item/all",
    posturl: "/server/catly/item"
  }
});
