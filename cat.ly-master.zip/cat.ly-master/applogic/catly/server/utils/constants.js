module.exports = Object.freeze({
	table_name: 'UrlShorten',
	short_url_segment: '700000000045786',
	errorPage: '/app/error.html'
});
